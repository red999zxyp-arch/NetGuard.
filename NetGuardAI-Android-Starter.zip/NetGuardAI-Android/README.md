# NetGuard AI — Android starter (0.1.0)

Primeira estrutura nativa criada a partir das especificações fornecidas. Ainda não é um APK compilado.

## O que esta base contém
- Aplicativo Android nativo em Kotlin, com identidade visual azul-escuro, verde e branco.
- Verificação da conectividade reconhecida pelo Android (Wi-Fi/Ethernet/dados móveis e estado `VALIDATED`).
- Teste HTTPS manual ou periódico a cada 10 segundos enquanto a tela permanece aberta.
- Medição do tempo total da requisição HTTPS e estimativa simples de jitter pela diferença absoluta entre medições válidas consecutivas.
- Histórico local limitado às últimas 1.000 medições e exportação CSV via seletor de arquivos do Android.
- Avisos explícitos de que latência HTTPS não é ping ICMP e falhas HTTPS não são perda de pacotes.

## Limitações desta base
- Não inclui serviço persistente em segundo plano nem monitoramento 24/7.
- Não mede perda de pacotes ICMP nem ping real.
- Não integra o roteador e não altera configurações de rede.
- Não inclui gráficos, IA remota ou diagnóstico avançado ainda.
- O monitoramento é pausado quando a Activity sai de primeiro plano.
- Esta pasta não contém Gradle Wrapper, porque Gradle não estava instalado no ambiente de auditoria. A compilação requer um ambiente Android com Gradle compatível, Android SDK 36 e JDK compatível.

## Compilar
Abra a pasta do projeto em um ambiente Android compatível (por exemplo, Android Studio ou uma IDE Android no celular que suporte projetos Gradle Kotlin DSL), configure o Android SDK 36 e execute a tarefa `:app:assembleDebug`. A primeira compilação pode precisar baixar plugins/dependências e de conexão à internet.

## Permissões
Somente `INTERNET` e `ACCESS_NETWORK_STATE` são declaradas nesta versão.
