package com.netguardai.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs

class MainActivity : Activity() {
    private val bg = Color.rgb(11, 18, 32)
    private val panel = Color.rgb(17, 30, 49)
    private val fg = Color.rgb(237, 244, 255)
    private val muted = Color.rgb(170, 187, 208)
    private val green = Color.rgb(64, 214, 160)
    private val handler = Handler(Looper.getMainLooper())
    private val executor = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("netguard_history", MODE_PRIVATE) }
    private val timeFormat = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US)

    private lateinit var statusText: TextView
    private lateinit var latencyText: TextView
    private lateinit var jitterText: TextView
    private lateinit var failuresText: TextView
    private lateinit var networkText: TextView
    private lateinit var lastText: TextView
    private lateinit var startButton: Button
    private lateinit var historyText: TextView
    private var running = false
    private var inFlight = false
    private var lastLatency: Long? = null
    private var totalProbes = 0
    private var failedProbes = 0
    private var lastResult = "Ainda não houve medições."

    private val periodicProbe = object : Runnable {
        override fun run() {
            if (running) {
                runProbe()
                handler.postDelayed(this, 10_000L)
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        updateNetworkState()
        refreshHistory()
    }

    override fun onResume() {
        super.onResume()
        updateNetworkState()
    }

    override fun onPause() {
        super.onPause()
        // Monitoramento intencionalmente limitado à tela aberta nesta primeira versão.
        handler.removeCallbacks(periodicProbe)
        running = false
        if (::startButton.isInitialized) startButton.text = "Iniciar monitoramento"
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        executor.shutdownNow()
        super.onDestroy()
    }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(bg) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(24))
            setBackgroundColor(bg)
        }
        scroll.addView(root)

        root.addView(label("NETGUARD AI", 12, green, true))
        root.addView(label("Monitor de conexão", 27, fg, true).also { it.setPadding(0, dp(4), 0, dp(3)) })
        root.addView(label("Medições locais • histórico privado", 14, muted, false))

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(16), dp(16), dp(16))
            setBackgroundColor(panel)
        }
        val cardParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(22) }
        root.addView(card, cardParams)
        card.addView(label("ESTADO", 12, muted, true))
        statusText = label("Pronto para medir", 21, green, true)
        card.addView(statusText)
        networkText = label("Rede: verificando…", 14, muted, false)
        card.addView(networkText)
        card.addView(divider())
        latencyText = label("Latência HTTPS: —", 17, fg, true)
        jitterText = label("Jitter estimado: —", 17, fg, true)
        failuresText = label("Falhas de requisição: —", 17, fg, true)
        lastText = label("Última verificação: —", 13, muted, false)
        card.addView(latencyText)
        card.addView(jitterText)
        card.addView(failuresText)
        card.addView(lastText)

        startButton = Button(this).apply {
            text = "Iniciar monitoramento"
            setTextColor(Color.rgb(6, 27, 22))
            setBackgroundColor(green)
            setOnClickListener { toggleMonitoring() }
        }
        root.addView(startButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })

        val testButton = Button(this).apply {
            text = "Executar teste único"
            setOnClickListener { runProbe() }
        }
        root.addView(testButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })

        root.addView(label("HISTÓRICO LOCAL", 13, green, true).apply { setPadding(0, dp(24), 0, dp(8)) })
        historyText = label("Nenhuma medição registrada.", 13, muted, false)
        root.addView(historyText)
        val exportButton = Button(this).apply {
            text = "Exportar histórico CSV"
            setOnClickListener { exportCsv() }
        }
        root.addView(exportButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(label(
            "Transparência: a latência medida é o tempo de uma requisição HTTPS, não ping ICMP. Falhas HTTPS não são perda de pacotes. O monitoramento para quando o app sai de primeiro plano nesta versão inicial.",
            12, muted, false
        ).apply { setPadding(0, dp(22), 0, 0) })

        setContentView(scroll)
    }

    private fun toggleMonitoring() {
        running = !running
        startButton.text = if (running) "Pausar monitoramento" else "Iniciar monitoramento"
        if (running) {
            statusText.text = "Monitoramento ativo nesta tela"
            handler.removeCallbacks(periodicProbe)
            handler.post(periodicProbe)
        } else {
            handler.removeCallbacks(periodicProbe)
            statusText.text = "Monitoramento pausado"
        }
    }

    private fun runProbe() {
        if (inFlight) return
        inFlight = true
        statusText.text = "Testando conexão…"
        executor.execute {
            val start = System.nanoTime()
            var success = false
            var code = -1
            var error = ""
            try {
                val connection = (URL("https://www.google.com/generate_204").openConnection() as HttpURLConnection).apply {
                    requestMethod = "GET"
                    connectTimeout = 4000
                    readTimeout = 4000
                    instanceFollowRedirects = false
                    useCaches = false
                }
                try {
                    code = connection.responseCode
                    success = code in 200..299
                } finally {
                    connection.disconnect()
                }
            } catch (e: Exception) {
                error = e.javaClass.simpleName
            }
            val elapsed = (System.nanoTime() - start) / 1_000_000L
            val timestamp = timeFormat.format(Date())
            runOnUiThread {
                inFlight = false
                totalProbes++
                val previous = lastLatency
                val jitter = if (success && previous != null) abs(elapsed - previous) else null
                if (success) {
                    lastLatency = elapsed
                    statusText.text = "Internet acessível"
                    statusText.setTextColor(green)
                } else {
                    failedProbes++
                    statusText.text = "Falha na requisição HTTPS"
                    statusText.setTextColor(Color.rgb(255, 115, 115))
                }
                latencyText.text = "Latência HTTPS: " + if (success) "$elapsed ms" else "indisponível"
                jitterText.text = "Jitter estimado: " + (jitter?.let { "$it ms" } ?: "aguardando outra medição válida")
                val pct = if (totalProbes > 0) failedProbes * 100.0 / totalProbes else 0.0
                failuresText.text = String.format(Locale.US, "Falhas HTTPS: %d/%d (%.1f%%)", failedProbes, totalProbes, pct)
                lastText.text = "Última verificação: $timestamp"
                networkText.text = "Rede do Android: ${networkSummary()}"
                val row = listOf(timestamp, success.toString(), if (success) elapsed.toString() else "", jitter?.toString() ?: "", code.toString(), error).joinToString(";")
                val existing = prefs.getString("rows", "") ?: ""
                val rows = (existing.split('\n').filter { it.isNotBlank() } + row).takeLast(1000)
                prefs.edit().putString("rows", rows.joinToString("\n")).apply()
                lastResult = if (success) "$timestamp — HTTPS ${elapsed}ms" else "$timestamp — falha ($error)"
                refreshHistory()
            }
        }
    }

    private fun updateNetworkState() {
        networkText.text = "Rede do Android: ${networkSummary()}"
    }

    private fun networkSummary(): String {
        val cm = getSystemService(CONNECTIVITY_SERVICE) as ConnectivityManager
        val network = cm.activeNetwork ?: return "sem rede ativa"
        val caps = cm.getNetworkCapabilities(network) ?: return "estado desconhecido"
        val transport = when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "dados móveis"
            else -> "outro transporte"
        }
        val validated = caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        return "$transport • internet ${if (validated) "validada pelo Android" else "não validada"}"
    }

    private fun refreshHistory() {
        if (!::historyText.isInitialized) return
        val rows = (prefs.getString("rows", "") ?: "").split('\n').filter { it.isNotBlank() }
        historyText.text = if (rows.isEmpty()) "Nenhuma medição registrada." else rows.takeLast(5).asReversed().joinToString("\n") { row ->
            val cols = row.split(';')
            val outcome = if (cols.getOrNull(1) == "true") "HTTPS ${cols.getOrNull(2)} ms" else "requisição falhou"
            "${cols.firstOrNull() ?: ""} — $outcome"
        }
    }

    private fun exportCsv() {
        val rows = prefs.getString("rows", "") ?: ""
        val csv = "timestamp;https_success;https_latency_ms;jitter_estimate_ms;http_code;error\n" + rows.replace(';', ';')
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "netguard-ai-historico.csv")
        }
        pendingCsv = csv
        @Suppress("DEPRECATION")
        startActivityForResult(intent, CREATE_CSV)
    }

    @Deprecated("Uses activity result for broad Android compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_CSV && resultCode == RESULT_OK && data?.data != null) {
            try {
                contentResolver.openOutputStream(data.data!!)?.bufferedWriter()?.use { it.write(pendingCsv) }
            } catch (e: Exception) {
                statusText.text = "Falha ao exportar CSV: ${e.javaClass.simpleName}"
            }
        }
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean): TextView = TextView(this).apply {
        this.text = text
        textSize = size.toFloat()
        setTextColor(color)
        if (bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
        setPadding(0, dp(5), 0, dp(5))
    }

    private fun divider(): View = View(this).apply {
        setBackgroundColor(Color.rgb(42, 59, 82))
        layoutParams = LinearLayout.LayoutParams(-1, dp(1)).apply { topMargin = dp(12); bottomMargin = dp(12) }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    companion object {
        private const val CREATE_CSV = 5102
        private var pendingCsv: String = ""
    }
}
